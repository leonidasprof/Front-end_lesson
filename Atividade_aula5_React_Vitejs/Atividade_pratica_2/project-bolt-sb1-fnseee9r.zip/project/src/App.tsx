import React from 'react';
import { Mail, Github, Linkedin, Music, Coffee, Book, Globe, Palette } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden max-w-sm w-full">
        {/* Profile Header */}
        <div className="relative h-48">
          <div className="absolute inset-0 bg-gradient-to-r from-orange-400 to-orange-500"></div>
          <img 
            src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80"
            alt="Profile background"
            className="w-full h-full object-cover opacity-90 mix-blend-overlay"
          />
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2">
            <div className="w-24 h-24 rounded-full border-4 border-white overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80"
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Profile Content */}
        <div className="pt-16 pb-8 px-6 text-center">
          <h2 className="text-2xl font-bold text-gray-800">Sarah Anderson</h2>
          <p className="text-orange-500 font-medium">Senior Product Designer</p>
          
          {/* Contact Links */}
          <div className="flex justify-center gap-4 mt-4">
            <button className="p-2 text-gray-600 hover:text-orange-500 transition-colors">
              <Mail size={20} />
            </button>
            <button className="p-2 text-gray-600 hover:text-orange-500 transition-colors">
              <Github size={20} />
            </button>
            <button className="p-2 text-gray-600 hover:text-orange-500 transition-colors">
              <Linkedin size={20} />
            </button>
          </div>

          {/* About Section */}
          <div className="mt-6">
            <h3 className="font-semibold text-gray-800 mb-2">About</h3>
            <p className="text-gray-600 text-sm">
              Passionate about creating beautiful and intuitive user experiences. 
              Specializing in UI/UX design with 5+ years of industry experience.
            </p>
          </div>

          {/* Interests */}
          <div className="mt-6">
            <h3 className="font-semibold text-gray-800 mb-3">Interests</h3>
            <div className="flex flex-wrap justify-center gap-2">
              {[
                { icon: Music, label: 'Music' },
                { icon: Coffee, label: 'Coffee' },
                { icon: Book, label: 'Reading' },
                { icon: Globe, label: 'Travel' },
                { icon: Palette, label: 'Art' }
              ].map((interest, index) => (
                <div key={index} className="flex items-center gap-1 bg-orange-50 text-orange-600 px-3 py-1 rounded-full text-sm">
                  <interest.icon size={14} />
                  <span>{interest.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;