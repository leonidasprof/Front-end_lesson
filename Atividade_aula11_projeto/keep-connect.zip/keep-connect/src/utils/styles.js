export const colors = {
    primary: '#FF7F48',
    secondary: '#222222',
    gray100: '#E6E6E6',
    gray200: '#BCBCBC'
}

export const shadows = {
    default: "0px 4px 10px 0px rgba(0,0,0,0.2)"
}