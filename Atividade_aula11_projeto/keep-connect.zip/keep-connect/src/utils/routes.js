const routes = {
    home: "/",
    createContact: "/create-contact"
}

export default routes