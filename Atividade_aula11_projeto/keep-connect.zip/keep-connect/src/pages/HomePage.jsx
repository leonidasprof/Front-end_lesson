import { useNavigate } from "react-router";
import AppButton from "../components/AppButton";
import ContactCard from "../components/ContactCard";
import EmptyList from "../components/EmptyList";
import { colors } from "../utils/styles";
import routes from "../utils/routes";
import styled from "styled-components";

const Header = styled.header`
  border-bottom: 2px solid ${colors.gray100};
  padding-bottom: 16px;
`;

function HomePage() {
  const navigate = useNavigate();

  const contactList = [
    {
      id: "1",
      name: "Djonathas Cardoso",
      email: "dcc@cesar.org.br",
      phone: "(81) 99999-1111",
    },
    {
      id: "2",
      name: "Lucas Marques",
      email: "lucas@email.com",
      phone: "(81) 99999-1111",
    },
  ];

  const goToCreateContact = () => {
    navigate(routes.createContact);
  };

  const handleDelete = (contactId) => {
    alert("Clicou para excluir o contato " + contactId);
  };

  return (
    <>
      <Header>
        <AppButton variant="outlined" onClick={goToCreateContact}>
          Novo contato
        </AppButton>
      </Header>
      <main>
        {contactList.length ? (
          contactList.map((contact) => (
            <ContactCard key={contact.id} contact={contact} onDelete={handleDelete} />
          ))
        ) : (
          <EmptyList />
        )}
      </main>
    </>
  );
}

export default HomePage;
