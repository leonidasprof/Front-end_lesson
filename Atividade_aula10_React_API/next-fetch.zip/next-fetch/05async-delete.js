async function deletePost(postId) {
  try {
    // Envia a requisição para deletar o post
    const response = await fetch(`https://jsonplaceholder.typicode.com/posts/${postId}`, {
      // Define o método como DELETE
      method: 'DELETE'
    });

    if (response.ok) {
      // Exibe uma mensagem de sucesso
      console.log(`Post ${postId} deletado com sucesso!`);
    } else {
      // Exibe uma mensagem de erro
      console.error("Erro ao deletar post.");
    }
  } catch (error) {
    // Exibe um erro, caso ocorra
    console.error("Erro ao deletar post:", error);
  }
}

deletePost(10);