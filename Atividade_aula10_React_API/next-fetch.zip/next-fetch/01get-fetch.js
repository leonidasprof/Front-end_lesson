
fetch('https://jsonplaceholder.typicode.com/posts')

  // Converte a resposta em JSON
  .then((response) => response.json())

  // Exibe a lista de posts
  .then((json) => console.log(json))

  // Exibe um erro, caso ocorra
  .catch((error) => console.error("Erro ao buscar posts:", error));