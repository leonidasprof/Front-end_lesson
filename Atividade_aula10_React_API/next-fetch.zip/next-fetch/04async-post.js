async function createPost() {
  // Cria um novo body para o ost
  const newPost = {
    user: "Lucas",
    idade: 23,
    legal: true
  };

  try {
    // Envia o novo post para o servidor
    const response = await fetch(
      'https://jsonplaceholder.typicode.com/users',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newPost)
      }
    );

    // Converte a resposta em JSON
    const data = await response.json();
    // Exibe o post criado
    console.log("User criado com sucesso:", data);
  } catch (error) {
    // Exibe um erro, caso ocorra
    console.error("Erro ao criar user:", error);
  }
}

createPost();