async function fetchUsers() {
  try {
    // Busca a lista de usuários
    const response = await fetch('https://jsonplaceholder.typicode.com/users');
    //  Converte a resposta em JSON
    const users = await response.json();

    // Exibe a lista de usuários
    console.log("Lista de usuários:");
    // Exibe o nome de cada usuário
    users.map(user => console.log(user.name));
  } catch (error) {
    // Exibe um erro, caso ocorra
    console.error("Erro ao buscar usuários:", error);
  }
}

fetchUsers();